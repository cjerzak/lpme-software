library(testthat)
library(lpme)

test_check("lpme")
