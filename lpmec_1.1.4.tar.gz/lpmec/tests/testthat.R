library(testthat)
library(lpmec)

test_check("lpmec")
