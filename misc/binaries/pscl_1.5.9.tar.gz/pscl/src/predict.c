#include <stdlib.h>
#include <math.h>
#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>
#include <R_ext/Print.h>

void predictCI(SEXP x, SEXP beta, SEXP cutoff) {


}
