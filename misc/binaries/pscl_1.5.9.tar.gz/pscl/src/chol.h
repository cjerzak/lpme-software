void choldc(double **a, int n, double p[]);

