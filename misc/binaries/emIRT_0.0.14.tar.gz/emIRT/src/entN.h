// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; tab-width: 4 -*-

#ifndef ENTN_H
#define ENTN_H

#include <RcppArmadillo.h>

double entN (const arma::mat &sigma
             ) ;

# endif
