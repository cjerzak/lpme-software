# ifndef ENTTN1_H
# define ENTTN1_H

double enttn1(const double mean,
              const double sd,
              const double low,
              const double high
              ) ;

# endif
