// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; tab-width: 4 -*-

# ifndef ETN1_H
# define ETN1_H

double etn1(const double mean,
            const double sd,
            const double low,
            const double high
            ) ;

# endif
